package dev.mooner.neonjs.jit.opt

import dev.mooner.neonjs.compiler.CodeUnit
import dev.mooner.neonjs.jit.CompiledCode
import dev.mooner.neonjs.jit.Jit
import dev.mooner.neonjs.vm.VmFrame

/**
 * The superclass of the optimizing tier's classes: the code of one block ([block]) with what it was compiled against
 * ([data]: objects the code compares with or reads, which a class cannot hold as constants), and the count of its
 * deoptimizations. Code that deoptimizes too often gives way to the baseline for good ([exit]).
 */
abstract class T2Code(@JvmField val data: Array<Any?>, @JvmField val block: CodeUnit) : CompiledCode {
    @JvmField var deopts = 0
    /** Exits by speculation (indexed as [data]), made when the first is taken; whether the code gave way already. */
    @JvmField var specExits: IntArray? = null
    @JvmField var reverted = false
    /** The definer the code came from, which its block's next compilation uses. */
    @JvmField var definer: dev.mooner.neonjs.jit.CodeDefiner? = null
    /** How an exit continues in the interpreter (the block's language's: T2.compile sets it). */
    @JvmField var resumer: Resumer = Resumer.NONE
    /** The loop headers the code can be entered at by on-stack replacement, sorted. */
    @JvmField var osrPcs: IntArray = IntArray(0)

    fun hasEntry(pc: Int): Boolean = java.util.Arrays.binarySearch(osrPcs, pc) >= 0

    /**
     * The code declined a frame at the loop header [pc] (a register without the kind it speculated on: an int sum that
     * overflowed in the interpreter, say): that entry is not offered again (Jit.osr goes to the baseline there).
     */
    fun declined(pc: Int) {
        osrPcs = osrPcs.filter { it != pc }.toIntArray()
    }

    companion object {
        /**
         * Deoptimizations after which a version of a block's code gives way to its baseline (and the block is compiled
         * again without the speculations that failed, [RECOMPILES] times at most, then not at all).
         */
        @JvmField val DEOPT_LIMIT = Integer.getInteger("neonjs.jit.t2DeoptLimit", 16)
        /**
         * Exits of one speculation after which the code gives way as well: one that keeps failing (an int sum that
         * overflows once a call) does not wait for [DEOPT_LIMIT] calls.
         */
        @JvmField val SPEC_LIMIT = Integer.getInteger("neonjs.jit.t2SpecLimit", 4)
        const val RECOMPILES = 3

        /**
         * An exit of [code] running [f] (its resumer) where the speculation [data] names (a [Speculation]) failed: it is
         * noted on its code block, and past [DEOPT_LIMIT] exits (or [SPEC_LIMIT] of this one) the block's baseline runs
         * new activations again (Jit.revert) while the block is compiled again, without the speculations that failed.
         */
        @JvmStatic
        fun exit(code: T2Code, f: VmFrame, pc: Int, values: Array<Any?>, inner: Any?, spec: Int): Any? {
            val s = code.data[spec] as Speculation
            synchronized(s.code) {
                (s.code.t2Failed ?: java.util.BitSet().also { s.code.t2Failed = it }).set(s.pc)
            }
            val counts = code.specExits ?: IntArray(code.data.size).also { code.specExits = it }
            val n = ++counts[spec]
            if ((++code.deopts >= DEOPT_LIMIT || n >= SPEC_LIMIT) && !code.reverted) {
                code.reverted = true
                Jit.revert(code.block, code)
                T2.reverted.incrementAndGet()
                val b = code.block
                if (++b.t2Recompiles > RECOMPILES) b.t2Off = true
                else code.definer?.let { T2.submit(b, it, f.agent.config.backgroundJit) }
            }
            return code.resumer.resume(f, pc, values, inner)
        }
    }
}

/**
 * How an exit of the optimizing tier's code continues the activation in its language's interpreter: [f], the frame the
 * code runs, at [pc] with [values] (its registers, then its operand stack), the calls compiled inlined around the exit
 * in [inner] (the language's records, innermost first, as its code generator made them). Returns the frame's result,
 * or VmRt.DEOPTED for a frame the interpreter gave the code (on-stack replacement), which goes on with it.
 */
fun interface Resumer {
    fun resume(f: VmFrame, pc: Int, values: Array<Any?>, inner: Any?): Any?

    companion object {
        /** Before the code's dialect gave its own (T2.instantiate): none. */
        @JvmField val NONE = Resumer { _, _, _, _ -> throw IllegalStateException("compiled code without its dialect's resumer") }
    }
}

/** A speculation an exit stands for: made at [pc] of [code] (pc [CodeUnit.code].size: the parameters). */
class Speculation(@JvmField val code: dev.mooner.neonjs.compiler.CodeUnit, @JvmField val pc: Int)
