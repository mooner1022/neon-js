package dev.mooner.neonjs.interop

import dev.mooner.neonjs.runtime.*
import dev.mooner.neonjs.vm.Iteration
import java.lang.reflect.Field
import java.lang.reflect.Method
import java.lang.reflect.Modifier

/** The most elements a List's `length` may be set to (ArrayList's own limit). */
private const val MAX_LIST_LENGTH = Int.MAX_VALUE - 8L

/** Callable wrapping one or more host method overloads, optionally bound to a receiver. */
class HostMethodFunction(
    @JvmField val bridge: HostBridge,
    name: String,
    @JvmField val overloads: List<Method>,
    @JvmField val target: Any?,
) : JSFunction(bridge.realm, bridge.realm.functionPrototype) {
    private var choice: HostBridge.Overloads? = null

    init {
        defineOwn("length", (overloads.minOfOrNull { it.parameterCount } ?: 0).toDouble(), Attr.CONFIGURABLE)
        defineOwn("name", name, Attr.CONFIGURABLE)
    }

    override fun call(thisArg: Any?, args: Array<Any?>): Any? {
        var recv = target
        if (recv == null && !Modifier.isStatic(overloads[0].modifiers)) {
            // unbound instance method: use thisArg
            recv = (thisArg as? HostObject)?.target ?: throw JSException.typeError("Host method ${debugName()} called on incompatible receiver")
        }
        val o = choice ?: bridge.overloads(overloads).also { choice = it }
        val i = bridge.selectIndex(o, args)
        if (i < 0) throw JSException.typeError("No applicable overload for ${debugName()} with arguments (${args.joinToString { Ops.typeOf(it) }})")
        return bridge.invoke(overloads[i], o.sigs[i], recv, args)
    }

    override fun sourceText(): String = "function ${debugName()}() { [native code] }"
}

/**
 * Exotic object exposing a host (Java/Kotlin) object's public members as properties: fields, methods, and
 * bean-style properties (getX/isX/setX, i.e. Kotlin properties). Where the policy allows the views
 * ([HostClassInfo.arrayLike], [HostClassInfo.mapLike], [HostClassInfo.iterable]), Java arrays and Lists are array-like,
 * Maps expose entries through get/set and Iterables are JS-iterable. Functions (lambdas, `@FunctionalInterface` and Kotlin function
 * type implementations, see [HostClassInfo.findFunctionalMethod]) are callable. A signature key such as
 * `append(java.lang.String)` names one overload ([HostClassInfo.overload]).
 *
 * An array-like one is a JS array to scripts, as GraalJS's foreign arrays are: `Array.prototype` is its prototype
 * (`map`, `filter`, `join`, `sort`, iteration by index...) and `Array.isArray` is true of it ([ForeignArray]). Its
 * Java members still come first (a List's `indexOf`, `forEach` and `sort` are Java's). A List grows and shrinks with
 * `push`, `pop`, `shift`, `unshift`, `splice`, a write just past its end and `length`; a Java array's length is fixed.
 */
class HostObject(@JvmField val bridge: HostBridge, @JvmField val target: Any, @JvmField val info: HostClassInfo) :
    JSObject(prototypeFor(bridge, info)), ForeignArray, ForeignMap, ForeignDate {

    /** Bound methods by [HostClassInfo.methodIndex] (one function per name, as reading a method twice gives). */
    private var bound: Array<HostMethodFunction?>? = null
    /** Bound methods named by signature keys. */
    private var methodCache: HashMap<String, HostMethodFunction>? = null

    init {
        special = special or SPECIAL_ALL
        if (info.functionalMethod != null) special = special or CALLABLE
        if (info.arrayLike) special = special or FOREIGN_ARRAY
        else if (info.mapLike) special = special or FOREIGN_MAP
        else if (info.dateLike) special = special or FOREIGN_DATE
        extensible = false
    }

    override val className: String get() = if (info.arrayLike) "Array" else if (info.dateLike && !info.mapLike) "Date" else "Object"

    private fun isArrayLike() = info.arrayLike

    private fun length(): Int = when (target) {
        is List<*> -> target.size
        else -> java.lang.reflect.Array.getLength(target)
    }

    private fun element(i: Int): Any? = when (target) {
        is List<*> -> target[i]
        else -> java.lang.reflect.Array.get(target, i)
    }

    private fun method(name: String): HostMethodFunction? {
        info.methodIndex[name]?.let { return boundMethod(it, name, info.instanceMethods[name]!!) }
        val m = info.overload(name, static = false) ?: return null
        var mc = methodCache
        if (mc == null) {
            mc = HashMap()
            methodCache = mc
        }
        return mc.getOrPut(name) { HostMethodFunction(bridge, name.substringBefore('('), listOf(m), target) }
    }

    private fun boundMethod(index: Int, name: String, list: List<Method>): HostMethodFunction {
        var b = bound
        if (b == null) {
            b = arrayOfNulls(info.methodIndex.size)
            bound = b
        }
        return b[index] ?: HostMethodFunction(bridge, name, list, target).also { b[index] = it }
    }

    /** As [get], with the member the site's key names in this class kept in the site (the same for its instances). */
    override fun getAt(site: PropSite): Any? {
        val c = site.aux
        if (c is HostMember && c.info === info) return read(c)
        val key = site.key
        if (key is String && !(key == "length" && isArrayLike())) {
            val m = info.member(key)
            if (m != null) {
                site.aux = m
                return read(m)
            }
        }
        return get(key, this)
    }

    private fun read(m: HostMember): Any? {
        m.field?.let { return bridge.toJS(read(it)) }
        m.methods?.let { return boundMethod(m.index, m.name, it) }
        return bridge.invoke(m.getter!!, target, EMPTY_ARGS)
    }

    private fun isMap() = info.mapLike

    private fun isIterable() = info.iterable

    /** True if [name] is a Java member (members take precedence over Map entries). */
    private fun isMember(name: String) = name in info.instanceFields || name in info.instanceMethods || name in info.instanceGetters

    /** Own member value or NotFound. */
    private fun member(key: Any): Any? {
        if (key is Int) {
            if (isArrayLike() && key < length()) return bridge.toJS(element(key))
            if (isMap()) return mapEntry(key.toString())
            return NotFound
        }
        if (key is JSSymbol) {
            // (an array-like one iterates as arrays do, by index: Array.prototype's iterator, as in GraalJS)
            if (key === JSSymbol.iterator && isIterable() && !isArrayLike()) return iteratorFunction()
            return NotFound
        }
        val name = key as String
        if (name == "length" && isArrayLike()) return length().toDouble()
        info.instanceFields[name]?.let { f -> return bridge.toJS(read(f)) }
        method(name)?.let { return it }
        info.instanceGetters[name]?.let { g -> return bridge.invoke(g, target, EMPTY_ARGS) }
        if (isMap()) return mapEntry(name)
        return NotFound
    }

    /** Java Map entries are visible as properties (Rhino-style) when the key is not a Java member name. */
    private fun mapEntry(name: String): Any? {
        @Suppress("UNCHECKED_CAST") val m = target as Map<Any?, Any?>
        val v = try {
            if (!containsKey(m, name)) return NotFound
            m[name]
        } catch (e: RuntimeException) {
            throw bridge.hostError(e)
        }
        return bridge.toJS(v)
    }

    private fun read(f: Field): Any? = try {
        f.get(target)
    } catch (_: IllegalAccessException) {
        throw JSException.typeError("Cannot access field ${f.name}")
    }

    /** The iterator of an Iterable or Iterator that is not array-like. */
    private fun iteratorFunction(): JSObject = NativeFunction(bridge.realm, "[Symbol.iterator]", 0, { f, _, _, _ ->
        val it: Iterator<Any?> = when (target) {
            is Iterable<*> -> target.iterator()
            else -> target as Iterator<*>
        }
        val o = JSObject(f.realm.iteratorPrototype)
        o.defineOwn("next", NativeFunction(f.realm, "next", 0, { nf, _, _, _ ->
            if (it.hasNext()) Iteration.createIterResult(nf.realm, bridge.toJS(it.next()), false)
            else Iteration.createIterResult(nf.realm, Undefined, true)
        }), Attr.WC)
        o
    })

    override fun getOwnValue(key: Any, receiver: Any?): Any? = member(key)

    override fun get(key: Any, receiver: Any?): Any? {
        val v = member(key)
        if (v !== NotFound) return v
        return proto?.get(key, receiver) ?: Undefined
    }

    /**
     * Attributes follow JS conventions: elements and Map entries are enumerable; methods and `length` are not; fields
     * and bean properties are enumerable except on collections (whose enumerable keys are just their entries).
     */
    override fun getOwnProperty(key: Any): PropertyDescriptor? {
        val v = member(key)
        if (v === NotFound) return null
        val collection = isMap() || isArrayLike()
        val attrs = when (key) {
            is Int -> Attr.WRITABLE or Attr.ENUMERABLE
            is String -> {
                val f = info.instanceFields[key]
                when {
                    // a List's length can be set (cut or padded); a Java array's cannot
                    key == "length" && isArrayLike() -> if (target is MutableList<*>) Attr.WRITABLE else 0
                    f != null -> (if (Modifier.isFinal(f.modifiers)) 0 else Attr.WRITABLE) or (if (collection) 0 else Attr.ENUMERABLE)
                    key in info.instanceMethods || info.overload(key, static = false) != null -> 0
                    key in info.instanceGetters -> (if (key in info.instanceSetters) Attr.WRITABLE else 0) or (if (collection) 0 else Attr.ENUMERABLE)
                    else -> Attr.WRITABLE or Attr.ENUMERABLE // Map entry
                }
            }
            else -> 0
        }
        return PropertyDescriptor.data(v, attrs)
    }

    override fun hasOwnProperty(key: Any): Boolean = member(key) !== NotFound

    override fun hasProperty(key: Any): Boolean = hasOwnProperty(key) || (proto?.hasProperty(key) ?: false)

    /** Element [i] (within the length) set to JS [value]; false where the collection refuses it (an immutable List). */
    private fun setElement(i: Int, value: Any?): Boolean = try {
        when (target) {
            is MutableList<*> -> {
                @Suppress("UNCHECKED_CAST") val list = target as MutableList<Any?>
                list[i] = bridge.toObject(value)
            }
            else -> java.lang.reflect.Array.set(target, i, bridge.toHost(value, target.javaClass.componentType))
        }
        true
    } catch (_: UnsupportedOperationException) {
        false
    } catch (e: IllegalArgumentException) {
        throw JSException.typeError("Cannot store ${Ops.describe(value)} in a ${target.javaClass.componentType.name} array: ${e.message}")
    }

    /**
     * As [ForeignArray] says. A replacement (as many items as removed elements) sets elements in place; otherwise a
     * List removes and inserts in one step each (`subList(...).clear()`, `addAll`), and a Java array, whose length is
     * fixed, refuses. So does a List that cannot change its length (`List.of`, `Arrays.asList`): its own
     * UnsupportedOperationException comes before any change.
     */
    override fun spliceElements(start: Int, deleteCount: Int, items: Array<Any?>): Array<Any?> {
        val removed = Array(deleteCount) { bridge.toJS(element(start + it)) }
        if (items.size == deleteCount) {
            for (i in items.indices) {
                if (!setElement(start + i, items[i])) throw JSException.typeError("Cannot assign to element ${start + i} of ${describeTarget()}")
            }
            return removed
        }
        if (target !is MutableList<*>) throw JSException.typeError("Cannot change the length of ${describeTarget()}")
        @Suppress("UNCHECKED_CAST") val list = target as MutableList<Any?>
        val added = items.map { bridge.toObject(it) }
        try {
            if (deleteCount > 0) list.subList(start, start + deleteCount).clear()
            if (added.isNotEmpty()) list.addAll(start, added)
        } catch (_: UnsupportedOperationException) {
            throw JSException.typeError("Cannot change the length of ${describeTarget()}")
        } catch (e: RuntimeException) {
            throw bridge.hostError(e)
        }
        return removed
    }

    /**
     * A List's `length` set to [value], as an array's would be: a valid array length or a RangeError, then the List
     * cut or padded with nulls (as GraalJS pads), the padding under the agent's limits. False where the List refuses.
     */
    private fun setListLength(value: Any?): Boolean {
        val d = Ops.toNumber(value)
        val n = Ops.toUint32(d)
        if (n.toDouble() != d) throw JSException.rangeError("Invalid array length")
        if (n > MAX_LIST_LENGTH) throw JSException.rangeError("Invalid length for ${describeTarget()}: $n")
        @Suppress("UNCHECKED_CAST") val list = target as MutableList<Any?>
        val newSize = n.toInt()
        try {
            val size = list.size
            if (newSize < size) list.subList(newSize, size).clear()
            // charged before it happens, as a new Java array is (a reference each)
            else bridge.realm.agent.reserveAllocation((newSize - size).toLong() * 4)
            var left = newSize - size
            while (left > 0) {
                val chunk = minOf(left, 1024)
                list.addAll(java.util.Collections.nCopies(chunk, null))
                left -= chunk
                if (left > 0) bridge.realm.agent.checkInterrupt()
            }
        } catch (_: UnsupportedOperationException) {
            return false
        } catch (e: RuntimeException) {
            throw bridge.hostError(e)
        }
        return true
    }

    /** JS [value] added at the end of the List; false where the List refuses. */
    private fun appendElement(value: Any?): Boolean = try {
        @Suppress("UNCHECKED_CAST") (target as MutableList<Any?>).add(bridge.toObject(value))
        true
    } catch (_: UnsupportedOperationException) {
        false
    }

    /** As [ForeignDate] says; nothing for an object the policy shows nothing of. */
    override fun foreignTimeValue(): Double? {
        if (!info.instancesVisible) return null
        return try {
            when (target) {
                is java.time.Instant -> target.toEpochMilli().toDouble()
                is java.time.ZonedDateTime -> target.toInstant().toEpochMilli().toDouble()
                is java.time.OffsetDateTime -> target.toInstant().toEpochMilli().toDouble()
                is java.time.LocalDateTime -> target.atZone(dev.mooner.neonjs.builtins.DateTime.zone).toInstant().toEpochMilli().toDouble()
                is java.time.LocalDate -> target.atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli().toDouble()
                is java.util.Date -> target.time.toDouble()
                else -> null
            }
        } catch (_: ArithmeticException) {
            Double.NaN // beyond a long of milliseconds: far outside what a Date holds
        }
    }

    @Suppress("UNCHECKED_CAST")
    private val map get() = target as MutableMap<Any?, Any?>

    /** [block] on the Map, its refusal to change a TypeError and its other failures host errors. */
    private inline fun <R> onMap(what: String, block: (MutableMap<Any?, Any?>) -> R): R = try {
        block(map)
    } catch (_: UnsupportedOperationException) {
        throw JSException.typeError("Cannot $what ${target.javaClass.name}")
    } catch (e: JSException) {
        throw e
    } catch (e: RuntimeException) {
        throw bridge.hostError(e)
    }

    /**
     * Whether Map [m] has [key]; a key it refuses to look up (a ClassCastException from a TreeMap of other keys, a
     * NullPointerException from `Map.of` given null) is no key of it. So `m.has` on a TreeMap of Integer keys is
     * Map.prototype's method rather than a failed lookup of the entry "has" (GraalJS throws there).
     */
    private fun containsKey(m: Map<Any?, Any?>, key: Any?): Boolean = try {
        m.containsKey(key)
    } catch (_: ClassCastException) {
        false
    } catch (_: NullPointerException) {
        false
    }

    override fun mapGet(key: Any?): Any? = onMap("read") { m ->
        val k = bridge.toObject(key)
        if (containsKey(m, k)) bridge.toJS(m[k]) else Undefined
    }

    override fun mapSet(key: Any?, value: Any?) {
        onMap("add to") { m -> m[bridge.toObject(key)] = bridge.toObject(value) }
    }

    override fun mapHas(key: Any?): Boolean = onMap("read") { m -> containsKey(m, bridge.toObject(key)) }

    override fun mapDelete(key: Any?): Boolean = onMap("remove from") { m ->
        val k = bridge.toObject(key)
        if (!containsKey(m, k)) false else {
            m.remove(k)
            true
        }
    }

    override fun mapClear() = onMap("clear") { m -> m.clear() }

    override fun mapSize(): Int = onMap("read") { m -> m.size }

    override fun mapCursor(): () -> Array<Any?>? {
        val keys = onMap("read") { m -> ArrayList(m.keys) }
        var i = 0
        return fun(): Array<Any?>? {
            while (i < keys.size) {
                if (i and 1023 == 1023) bridge.realm.agent.checkInterrupt()
                val k = keys[i++]
                val present = onMap("read") { m -> if (m.containsKey(k)) m[k] else NotFound }
                if (present !== NotFound) return arrayOf(bridge.toJS(k), bridge.toJS(present))
            }
            return null
        }
    }

    /** "a Java array (int[])", or the List's class name, for messages. */
    private fun describeTarget(): String = if (target.javaClass.isArray) "a Java array (${target.javaClass.typeName})" else target.javaClass.name

    override fun set(key: Any, value: Any?, receiver: Any?): Boolean {
        if (receiver !== this) return false
        if (key is Int && isArrayLike()) {
            val n = length()
            if (key < n) return setElement(key, value)
            // just past the end, a List grows by one (as in GraalJS); further on, and on a Java array, nothing
            return key == n && target is MutableList<*> && appendElement(value)
        }
        if (key is Int && isMap()) return mapPut(key.toString(), value)
        if (key !is String) return false
        if (key == "length" && isArrayLike() && target is MutableList<*>) return setListLength(value)
        if (isMap() && !isMember(key)) return mapPut(key, value)
        val f = info.instanceFields[key]
        if (f != null) {
            if (Modifier.isFinal(f.modifiers)) return false
            try {
                f.set(target, bridge.toField(value, f))
            } catch (_: IllegalAccessException) {
                return false
            } catch (e: IllegalArgumentException) {
                throw JSException.typeError("Cannot set field $key: ${e.message}")
            }
            return true
        }
        val setters = info.instanceSetters[key]
        if (setters != null) {
            val m = bridge.choose(setters, arrayOf(value)) ?: throw JSException.typeError("Cannot convert value for property $key")
            bridge.invoke(m, target, arrayOf(value))
            return true
        }
        return false
    }

    override fun defineOwnProperty(key: Any, desc: PropertyDescriptor): Boolean {
        if (desc.isAccessor) return false
        if (!desc.hasValue) return hasOwnProperty(key)
        return set(key, desc.value, this)
    }

    private fun mapPut(name: String, value: Any?): Boolean {
        @Suppress("UNCHECKED_CAST") val m = target as MutableMap<Any?, Any?>
        return try {
            m[name] = bridge.toObject(value)
            true
        } catch (_: UnsupportedOperationException) {
            false
        } catch (e: RuntimeException) {
            throw bridge.hostError(e)
        }
    }

    override fun delete(key: Any): Boolean {
        if (isMap() && (key is String && !isMember(key) || key is Int)) {
            val name = key.toString()
            @Suppress("UNCHECKED_CAST") val m = target as MutableMap<Any?, Any?>
            if (!m.containsKey(name)) return true
            return try {
                m.remove(name)
                true
            } catch (_: UnsupportedOperationException) {
                false
            }
        }
        return !hasOwnProperty(key)
    }

    override fun ownPropertyKeys(): MutableList<Any> {
        val out = ArrayList<Any>()
        if (isArrayLike()) {
            for (i in 0 until length()) out.add(i)
            out.add("length")
        }
        if (isMap()) {
            var n = 0
            for (k in (target as Map<*, *>).keys) {
                if (k is String && !isMember(k)) out.add(PK.fromString(k))
                if (++n and 1023 == 0) bridge.realm.agent.checkInterrupt()
            }
        }
        out.addAll(info.instanceFields.keys)
        out.addAll(info.instanceGetters.keys)
        out.addAll(info.instanceMethods.keys)
        return out
    }

    override fun setPrototypeOf(p: JSObject?): Boolean = p === proto
    override fun preventExtensions(): Boolean = true
    override fun isExtensible(): Boolean = false

    override fun call(thisArg: Any?, args: Array<Any?>): Any? {
        val m = info.functionalMethod ?: throw JSException.typeError("Host object is not callable")
        val all = info.callOverloads ?: (bridge.classInfo(m.declaringClass).instanceMethods[m.name]
            ?.filter { it.parameterCount == m.parameterCount }?.ifEmpty { null } ?: listOf(m)).also { info.callOverloads = it }
        val chosen = bridge.choose(all, args) ?: m
        if (chosen.parameterCount != args.size && !chosen.isVarArgs) {
            val padded = Array(chosen.parameterCount) { i -> if (i < args.size) args[i] else Undefined }
            return bridge.invoke(chosen, target, padded)
        }
        return bridge.invoke(chosen, target, args)
    }

    override fun toString(): String = "HostObject[${target.javaClass.name}]"
}

/**
 * The prototype a host object gets, as GraalJS gives foreign objects one: `Array.prototype` for an array-like one,
 * `Map.prototype` for a Map whose entries the policy shows, `Date.prototype` for a date-time naming an instant,
 * `Function.prototype` for a function (a lambda: `f.call`, `f.bind`), else `Object.prototype`. The policy decides first
 * ([HostClassInfo.arrayLike], [HostClassInfo.mapLike], [HostClassInfo.dateLike], [HostClassInfo.functionalMethod]).
 */
private fun prototypeFor(bridge: HostBridge, info: HostClassInfo): JSObject = when {
    info.arrayLike -> bridge.realm.arrayPrototype
    info.mapLike -> bridge.realm.intrinsic("%Map.prototype%")
    info.dateLike -> bridge.realm.intrinsic("%Date.prototype%")
    info.functionalMethod != null -> bridge.realm.functionPrototype
    else -> bridge.realm.objectPrototype
}

/** JS view of a host class: static members, constructor (`new`), instanceof checks and nested classes. */
class HostClassObject(@JvmField val bridge: HostBridge, @JvmField val cls: Class<*>) : JSObject(bridge.realm.functionPrototype) {
    @JvmField val info = bridge.classInfo(cls)
    private var methodCache = HashMap<String, HostMethodFunction>()

    /** Kotlin companion object (its members are also visible on the class, like @JvmStatic ones). */
    private val companion: HostObject? by lazy {
        val f = info.staticFields["Companion"] ?: return@lazy null
        val c = try { f.get(null) } catch (_: IllegalAccessException) { null } ?: return@lazy null
        bridge.toJS(c) as? HostObject
    }

    init {
        special = special or SPECIAL_ALL or CALLABLE
        if (info.constructors.isNotEmpty() || (cls.isInterface && bridge.access.allowImplementations) || cls.isArray) special = special or CONSTRUCTOR
        extensible = false
    }

    override val className: String get() = "Function"

    private fun member(key: Any): Any? {
        if (key === JSSymbol.hasInstance) {
            return NativeFunction(bridge.realm, "[Symbol.hasInstance]", 1, { _, _, a, _ ->
                val v = a.arg(0)
                // a host object of the class, or a HostError whose exception is one (`e instanceof IOException`)
                v is HostObject && cls.isInstance(v.target) || v is JSObject && bridge.hostCauseOf(v)?.let { cls.isInstance(it) } == true
            })
        }
        if (key !is String) return NotFound
        if (key == "name") return cls.simpleName
        if (key == "length") return (info.constructors.minOfOrNull { it.parameterCount } ?: 0).toDouble()
        info.staticFields[key]?.let { f ->
            return try { bridge.toJS(f.get(null)) } catch (_: IllegalAccessException) { throw JSException.typeError("Cannot access field $key") }
        }
        info.staticMethods[key]?.let { list -> return methodCache.getOrPut(key) { HostMethodFunction(bridge, key, list, null) } }
        info.overload(key, static = true)?.let { m -> return methodCache.getOrPut(key) { HostMethodFunction(bridge, key.substringBefore('('), listOf(m), null) } }
        info.staticGetters[key]?.let { g -> return bridge.invoke(g, null, EMPTY_ARGS) }
        info.memberClasses[key]?.let { return bridge.classObject(it) }
        if (cls.isEnum) {
            val c = cls.enumConstants.firstOrNull { (it as Enum<*>).name == key }
            if (c != null) return bridge.toJS(c)
        }
        companion?.let { c ->
            val v = c.getOwnValue(key, c)
            if (v !== NotFound) return v
        }
        return NotFound
    }

    override fun getOwnValue(key: Any, receiver: Any?): Any? = member(key)

    override fun get(key: Any, receiver: Any?): Any? {
        val v = member(key)
        if (v !== NotFound) return v
        return proto?.get(key, receiver) ?: Undefined
    }

    override fun getOwnProperty(key: Any): PropertyDescriptor? {
        val v = member(key)
        if (v === NotFound) return null
        return PropertyDescriptor.data(v, Attr.ENUMERABLE)
    }

    override fun hasOwnProperty(key: Any): Boolean = member(key) !== NotFound
    override fun hasProperty(key: Any): Boolean = hasOwnProperty(key) || (proto?.hasProperty(key) ?: false)

    override fun set(key: Any, value: Any?, receiver: Any?): Boolean {
        if (key !is String) return false
        val f = info.staticFields[key]
        if (f != null && !Modifier.isFinal(f.modifiers)) {
            try {
                f.set(null, bridge.toField(value, f))
            } catch (_: IllegalAccessException) {
                return false
            } catch (e: IllegalArgumentException) {
                throw JSException.typeError("Cannot set field $key: ${e.message}")
            }
            return true
        }
        val setters = info.staticSetters[key]
        if (setters == null) {
            val c = companion ?: return false
            return c.set(key, value, c)
        }
        val m = bridge.choose(setters, arrayOf(value)) ?: return false
        bridge.invoke(m, null, arrayOf(value))
        return true
    }

    override fun defineOwnProperty(key: Any, desc: PropertyDescriptor): Boolean = false
    override fun delete(key: Any): Boolean = !hasOwnProperty(key)
    override fun ownPropertyKeys(): MutableList<Any> {
        val out = ArrayList<Any>()
        out.addAll(info.staticFields.keys)
        out.addAll(info.staticGetters.keys)
        out.addAll(info.staticMethods.keys)
        out.addAll(info.memberClasses.keys)
        return out
    }
    override fun setPrototypeOf(p: JSObject?): Boolean = p === proto
    override fun preventExtensions(): Boolean = true
    override fun isExtensible(): Boolean = false

    override fun call(thisArg: Any?, args: Array<Any?>): Any? =
        throw JSException.typeError("Host class ${cls.simpleName} must be invoked with 'new'")

    override fun construct(args: Array<Any?>, newTarget: JSObject): Any? {
        if (cls.isArray) return bridge.newArray(cls.componentType, args.arg(0))
        if (cls.isInterface) {
            val impl = args.arg(0) as? JSObject ?: throw JSException.typeError("Implementing ${cls.simpleName} requires a function or object")
            return bridge.toJS(bridge.implement(impl, cls))
        }
        val c = bridge.choose(info.constructors, args)
            ?: throw JSException.typeError("No applicable constructor for ${cls.simpleName} with arguments (${args.joinToString { Ops.typeOf(it) }})")
        return bridge.construct(c, args)
    }

    override fun toString(): String = "HostClass[${cls.name}]"
}
