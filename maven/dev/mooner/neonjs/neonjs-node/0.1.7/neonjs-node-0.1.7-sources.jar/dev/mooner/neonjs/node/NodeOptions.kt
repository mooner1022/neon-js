package dev.mooner.neonjs.node

import java.util.function.IntConsumer

/**
 * What the Node.js APIs of a context see of the host. Nothing of the host's own environment shows unless given
 * here: `process.env` is empty by default, and `process.exit` never ends the host process.
 */
class NodeOptions private constructor(b: Builder) {
    /** `process.env` (default: empty). */
    val env: Map<String, String> = b.env.toMap()
    /** `process.argv` (default: `["neonjs"]`). */
    val argv: List<String> = b.argv.toList()
    /**
     * `process.platform`, which also gives node:path, node:url and node:os their rules, POSIX or Windows (default: the
     * host's: `android` on Android, else `win32`, `darwin` or `linux` by the host's OS).
     */
    val platform: String = b.platform ?: hostPlatform()
    /**
     * `process.cwd()` and what relative paths resolve against (default: the root of [platform]: `C:\` on `win32`,
     * else `/`; never the host's own working directory).
     */
    val cwd: String = b.cwd ?: if (platform == "win32") "C:\\" else "/"
    /** Called with the code of `process.exit(code)`; by default the context's evaluation is interrupted. */
    val onExit: IntConsumer? = b.onExit
    /**
     * Whether `console` formats as Node's does, with node:util's format and inspect (default: true): objects show as
     * their libraries mean them to (`[util.inspect.custom]`), which runs guest code while logging. When false, the
     * console keeps the core's formatting, which never runs guest code.
     */
    val consoleInspect: Boolean = b.consoleInspect

    class Builder {
        internal val env = LinkedHashMap<String, String>()
        internal val argv = arrayListOf("neonjs")
        internal var cwd: String? = null
        internal var platform: String? = null
        internal var onExit: IntConsumer? = null
        internal var consoleInspect = true

        fun env(vars: Map<String, String>) = apply { env.clear(); env.putAll(vars) }
        fun argv(args: List<String>) = apply { argv.clear(); argv.addAll(args) }
        fun cwd(path: String) = apply { cwd = path }
        fun platform(name: String) = apply { platform = name }
        fun onExit(callback: IntConsumer) = apply { onExit = callback }
        fun consoleInspect(enabled: Boolean) = apply { consoleInspect = enabled }
        fun build() = NodeOptions(this)
    }

    companion object {
        @JvmField val DEFAULT: NodeOptions = Builder().build()

        @JvmStatic fun builder() = Builder()

        private fun hostPlatform(): String {
            if (System.getProperty("java.vendor", "").contains("Android", ignoreCase = true)) return "android"
            val os = System.getProperty("os.name", "").lowercase()
            return when {
                os.startsWith("windows") -> "win32"
                os.startsWith("mac") || os.startsWith("darwin") -> "darwin"
                else -> "linux"
            }
        }
    }
}
